﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ColegioCovid
{
    class Alumno
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public string apellidos { get; set; }
        public int telefono { get; set; }
        public string fecha_nac { get; set; }
        public string sexo { get; set; }
        public string curso { get; set; }
        //public bool check { get; set; }
    }
}
