﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ColegioCovid
{
    class Aula
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public int planta { get; set; }
        public int capacidad { get; set; }
    }
}
