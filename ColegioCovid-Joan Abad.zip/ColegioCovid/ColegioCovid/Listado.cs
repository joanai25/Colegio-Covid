﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ColegioCovid
{
    class Listado
    {
        public int id { get; set; }
        public int id_alu { get; set; }
        public int id_aula { get; set; }
        public string hora { get; set; }
        public string fecha { get; set; }
    }
}
