﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ColegioCovid
{
    class Infectado
    {
        public string nombre { get; set; }
        public string apellidos { get; set; }
        public string fecha { get; set; }
        public string hora { get; set; }
    }
}
